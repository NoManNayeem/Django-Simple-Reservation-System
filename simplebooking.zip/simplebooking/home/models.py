from django.db import models
from django.utils import timezone
import datetime

# Create your models here.
class Room(models.Model):

   name = models.CharField(max_length = 200)
#    img = models.ImageField(upload_to='Pictures')
   desc = models.CharField(max_length = 200)
   price = models.IntegerField()
   is_reserved = models.BooleanField(default=False)
   number_of_people = models.PositiveIntegerField()


   def __str__(self):
       return self.name

   class Meta:
       verbose_name = 'Room'
       verbose_name_plural = 'Rooms'


class Guest(models.Model):

    fullname = models.CharField(max_length = 200)
    email = models.CharField(max_length = 200)
    phone = models.CharField(max_length = 200)

    def __str__(self):
       return self.fullname


    class Meta:
       verbose_name = 'Guest'
       verbose_name_plural = 'Guests'


class Reservation(models.Model):

    check_in = models.DateField(default=timezone.now)
    check_out = models.DateField()
    room = models.ForeignKey(Room, on_delete = models.CASCADE)
    guest = models.ForeignKey(Guest, on_delete= models.CASCADE)

    def __str__(self):
       return f'{self.guest} @ Room: {self.room}'
    class Meta:
       verbose_name = 'Reservation'
       verbose_name_plural = 'Reservations'

