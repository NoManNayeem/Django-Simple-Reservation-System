from django.shortcuts import render, HttpResponse, redirect, HttpResponseRedirect
from home.models import *
from datetime import datetime
from datetime import date
from django.contrib import messages


date_format = "%Y-%m-%d"
# Create your views here.
def index(request):
    today = date.today()
    inactive_bookings = Reservation.objects.filter(check_out__lte=today)
    for booking in inactive_bookings.iterator():
        empty_room = Room.objects.get(pk=booking.room.id)
        empty_room.is_reserved=False
        empty_room.save()
    active_bookings = Reservation.objects.filter(check_out__gte=today)
    for booking in active_bookings.iterator():
        empty_room = Room.objects.get(pk=booking.room.id)
        empty_room.is_reserved=True
        empty_room.save()
    available_rooms = Room.objects.filter(is_reserved=False)
    # return render(request, "index.html",{'available_rooms':available_rooms})
    available_rooms = Room.objects.all()
    return render(request, "index.html",{'available_rooms':available_rooms})




def book(request):
    if request.method=="POST":
        fullname = request.POST.get('fullname')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        fetchroom = request.POST.get('room')
        no_of_guests = request.POST.get('guests')
        checkin = request.POST.get('checkin')
        checkout = request.POST.get('checkout')
        a = datetime.strptime(checkin, date_format)
        b = datetime.strptime(checkout, date_format)
        today = datetime.today()
        # today = datetime.strptime(today, '%Y-%m-%d %H:%M:%S')
        

        # New Work
        # invalid_dates = False
        #get the room 
        room = Room.objects.get(pk=fetchroom)
        # guest_id = request.user
        days = (b.date()-a.date()).days
        if (days<1):
            messages.warning(request,"Invalid Dates")
            return HttpResponseRedirect("/")
        elif (a<today):
            messages.warning(request,"Invalid Dates")
            return HttpResponseRedirect("/")
        elif (b<today):
            messages.warning(request,"Invalid Dates")
            return HttpResponseRedirect("/")
        else:
            check_in = a 
            check_out = b
        # check wether the dates are valid
        # case 1: a room is booked before the check_in date, and checks out after the requested check_in date
        case_1 = Reservation.objects.filter(room=room, check_in__lte=check_in, check_out__gte=check_in).exists()

        # case 2: a room is booked before the requested check_in date and check_out date is after requested check_out date
        case_2 = Reservation.objects.filter(room=room, check_in__lte=check_out, check_out__gte=check_out).exists()
            
        case_3 = Reservation.objects.filter(room=room, check_in__gte=check_in, check_out__lte=check_out).exists()


        # if either of these is true, abort and render the error
        if case_1 or case_2 or case_3:
            messages.warning(request,"This room is not available on your selected dates")
            return HttpResponseRedirect("/")                  
             
        # End New Work
        try:
            guest = Guest.objects.get(fullname=fullname,email=email, phone=phone)
        except:
            guest = Guest(fullname=fullname, email=email, phone=phone)
            guest.save()
        newroom = Room.objects.get(pk=fetchroom)
        reservation = Reservation(check_in=check_in, check_out=check_out, guest=guest, room = newroom)
        newroom.is_reserved=True
        newroom.save()
        reservation.save()
        messages.success(request,"Reservation Done Successfully")
        
        days = (b.date()-a.date()).days
        total = (newroom.price)*days
        
        context = {

            'cust_name' : fullname,
            'cust_email' : email,
            'cust_phone' : phone,
            'checkin' : a,
            'checkout' : b,
            'orderdate' : today,
            'guest': no_of_guests,
            'days' : days,
            'room': newroom,
            'total': total

        }
        return render(request, "invoice.html", context)
